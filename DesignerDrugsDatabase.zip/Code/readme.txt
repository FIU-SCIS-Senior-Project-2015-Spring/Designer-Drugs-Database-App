the directory structure is as follows:
/css/ 
     Contains all the styles that the application uses, including those of bootstrap.

/database/
    as per request of the professor contains the .sql of the latest version of the database

/fonts/
    contains fonts that bootstrap uses

/functions/ 
    contains a javascript page called functions.js that contains the generic controller, a route function and some global variables of the system. this page is seen from every page of the system

/img/ 
    contains all the pictures of the system, including the ones of the compounds.

/js/
    contains the javascript that angular and bottstrap framework uses

/pages/ 
    contains all the pages snipets that are visible within the system

/request/
    contains all the php pages that access to the database.