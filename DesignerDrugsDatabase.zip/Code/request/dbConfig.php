<?php
$dbConfig = array();
$dbConfig["Address"] = "localhost";
$dbConfig["Name"] = "drugsdb";
$dbConfig["User"] = "root";
$dbConfig["Password"] = "";
?>